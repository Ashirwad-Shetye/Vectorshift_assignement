import {Icons} from '../../components/ui/icon'

export const NodeTypeMapping = {
    "customInput" : <Icons.InputIcon/>,
    "llm" : <Icons.LLMIcon/>,
    "customOutput" : <Icons.OutputIcon/>,
    "text" : <Icons.TextIcon/>,
    "note" : <Icons.NoteIcon/>,
    "database" : <Icons.DatabaseIcon/>,
    "youtube" : <Icons.YoutubeIcon/>,
    "git" : <Icons.GitIcon/>,
    "discord" : <Icons.DiscordIcon/>,
}