import { NodeTypeMapping } from "./utils/constants/constants";

export const DraggableNode = ({ type, label }) => {
    const onDragStart = (event, nodeType) => {
      const appData = { nodeType }
      event.target.style.cursor = 'grabbing';
      event.dataTransfer.setData('application/reactflow', JSON.stringify(appData));
      event.dataTransfer.effectAllowed = 'move';
    };
  
    return (
      <div
        className="cursor-grab border-2 border-gray-300 text-gray-500 min-w-[60px] h-14 flex items-center rounded-md justify-center 
        flex-col gap-1 hover:scale-105 active:scale-95 duration-200 hover:shadow-md"
        onDragStart={(event) => onDragStart(event, type)}
        onDragEnd={(event) => (event.target.style.cursor = 'grab')}
        draggable
      >
        <div className="text-lg shrink-0">
          {NodeTypeMapping[type]}
        </div>
          <span className="text-xs">{label}</span>
      </div>
    );
  };
  