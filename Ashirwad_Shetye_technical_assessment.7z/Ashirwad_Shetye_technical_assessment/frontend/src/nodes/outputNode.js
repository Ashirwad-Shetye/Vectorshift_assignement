import React, { useState } from 'react';
import { BaseNode } from './baseNode';
import {Icons} from '../components/ui/icon'

export const OutputNode = ({ id, data }) => {
  const [currName, setCurrName] = useState(data?.inputName);
  const [outputType, setOutputType] = useState(data.outputType || 'Text');

  const optionValues = ["Text", "File", "Audio"]

  return (
    <BaseNode id={id} inputs={['value']}>
      <div className='flex items-center font-semibold gap-1 text-[#6563e4]'>
        <Icons.OutputIcon/>
        <h1 className=''>Output</h1>
      </div>
      <div className='mt-3 flex flex-col gap-2'>
        <label className='text-xs gap-1 text-gray-600 flex flex-col'>
          Field Name:
          <input
            type="text"
            value={currName}
            placeholder='Enter field name...'
            onChange={(e) => setCurrName(e.target.value)}
            className='text-sm focus:outline-none focus:text-black text-gray-500'
          />
        </label>
        <label className='text-xs gap-1 text-gray-600 flex flex-col'>
          Type:
          <select
            value={outputType}
            onChange={(e) => setOutputType(e.target.value)}
            className='text-sm focus:outline-none focus:text-black text-gray-500'
          >
            {optionValues.map((val, idx) => {
              return (
                <option
                  key={idx}
                  value={val}
                >
                  {val}
                </option>
              )
            })}
          </select>
        </label>
      </div>
    </BaseNode>
  );
};