import React, { useState } from 'react';
import { BaseNode } from './baseNode';
import {Icons} from '../components/ui/icon'

export const DatabaseNode = ({ id, data }) => {
  const [inputType, setInputType] = useState(data.inputType || 'MongoDB');

  const optionValues = ["MongoDB", "PostgreSQL", "Cassandra", "CockroachDB", "SQLite", "ElasticSearch"]

  return (
    <BaseNode id={id} outputs={['value']} inputs={['value']}>
      <div className='flex items-center font-semibold gap-1 text-[#6563e4]'>
        <Icons.DatabaseIcon/>
        <h1 className=''>Database</h1>
      </div>
      <div className='mt-3 flex flex-col gap-2'>
        <label className='text-xs gap-1 text-gray-600 flex flex-col'>
          Database type:
          <select
            value={inputType}
            onChange={(e) => setInputType(e.target.value)}
            className='text-sm focus:outline-none focus:text-black text-gray-500'
          >
            {optionValues.map((val, idx) => {
              return (
                <option
                  key={idx}
                  value={val}
                >
                  {val}
                </option>
              )
            })}
          </select>
        </label>
      </div>
    </BaseNode>
  );
};