import React, { useState, useRef, useEffect } from 'react';
import { BaseNode } from './baseNode';
import { Icons } from '../components/ui/icon';
import { Handle, Position } from 'reactflow';

export const TextNode = ({ id, data }) => {
  const [currText, setCurrText] = useState(data?.text || '{{input}}');
  const [variables, setVariables] = useState([]);
  const textareaRef = useRef(null);

  const handleTextChange = (e) => {
    setCurrText(e.target.value);
  };

  useEffect(() => {
    const textarea = textareaRef.current;
    textarea.style.height = 'auto';
    textarea.style.height = `${Math.min(textarea.scrollHeight, 320)}px`;

    const variablePattern = /\{\{(\w+)\}\}/g;
    const matches = [...currText.matchAll(variablePattern)];
    const detectedVariables = matches.map(match => match[1]);
    setVariables(detectedVariables);
  }, [currText]);

  return (
    <BaseNode id={id} data={data} outputs={['output']}>
      <div className='flex items-center font-semibold gap-1 text-[#6563e4]'>
        <Icons.TextIcon />
        <h1 className=''>Text</h1>
      </div>
      <div className='w-full flex flex-col mt-3'>
        <label className='text-xs gap-1 text-gray-600 flex flex-col'>
          <h3 className=''>Text:</h3>
          <textarea
            ref={textareaRef}
            type="text"
            value={currText}
            onChange={handleTextChange}
            className='p-2 text-wrap rounded resize-none border-2'
            style={{ maxHeight: '20rem', overflowY: 'auto' }}
          />
        </label>
      </div>
      <div className='absolute flex flex-col gap-10 items-center left-0 top-1/2 transform -translate-y-1/2'>
        {variables.map((variable, index) => {
          const handleHeight = 10;
          const handleSpacing = (100 - (variables.length - 1) * handleHeight) / (variables.length - 1);

          return (
            <div key={`handle-${variable}`} className='relative'>
              <div
                className='absolute top-0 right-2 text-xs text-gray-500 px-1 py-0.5 rounded'
                style={{ marginLeft: '0.5rem' }}
              >
                {variable}
              </div>
              <Handle
                key={`input-${variable}`}
                type="target"
                position={Position.Left}
                id={`${id}-${variable}`}
                style={{
                  top: `${index * handleSpacing}%`,
                  left: "-0.4rem",
                  backgroundColor: '#ff5722',
                  borderRadius: '50%',       
                  width: '10px',             
                  height: '10px', 
                }}
              />
            </div>
          );
        })}
      </div>
    </BaseNode>
  );
};
