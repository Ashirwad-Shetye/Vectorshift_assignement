import React, { useEffect, useRef } from 'react';
import { Handle, Position, useReactFlow } from 'reactflow';
import { Icons } from '../components/ui/icon';
import { useFocus } from '../context/FocusProvider';

export const BaseNode = ({ id, data, children, inputs = [], outputs = [], style = {} }) => {
  const { deleteElements } = useReactFlow();
  const { focusedNodeId, setFocusedNodeId } = useFocus();
  const nodeRef = useRef(null);

  const isFocused = focusedNodeId === id;

  const handleDelete = () => {
    deleteElements({ nodes: [{ id }] });
  };

  const handleFocus = () => {
    setFocusedNodeId(id);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (nodeRef.current && !nodeRef.current.contains(event.target)) {
        if (isFocused) {
          setFocusedNodeId(null);
        }
      }
    };

    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isFocused, setFocusedNodeId]);

  
  const handleStyles = {
    input: {
      backgroundColor: '#ff5722',
      borderRadius: '50%',       
      width: '10px',             
      height: '10px',            
    },
    output: {
      backgroundColor: '#4caf50',
      borderRadius: '50%',       
      width: '10px',             
      height: '10px',            
    }
  };

  return (
    <div
      ref={nodeRef}
      className={`w-56 h-fit border-[2px] bg-white transition-colors p-2 rounded-lg relative 
        ${isFocused ? 'border-[#6563e4] shadow shadow-[#6563e4]' : ''}`}
      style={{ ...style }}
      onClick={handleFocus}
    >
      {inputs.map((input, index) => (
        <Handle
          key={`input-${index}`}
          type="target"
          position={Position.Left}
          id={`${id}-${input}`}
          style={{
            top: `${((index + 1) * 100) / (inputs.length + 1)}%`,
            left: "-0.4rem",
            ...handleStyles.input
          }}
        />
      ))}
      <div className='absolute flex items-center gap-2 right-2 top-2 text-gray-500'>
        <button className='hover:scale-105 active:scale-95 duration-200'>
          <Icons.InfoIcon />
        </button>
        <button
          className='hover:scale-105 active:scale-95 duration-200 hover:text-red-500'
          onClick={handleDelete}
        >
          <Icons.CloseIcon />
        </button>
      </div>
      {children}
      {outputs.map((output, index) => (
        <Handle
          key={`output-${index}`}
          type="source"
          position={Position.Right}
          id={`${id}-${output}`}
          style={{
            top: `${((index + 1) * 100) / (outputs.length + 1)}%`,
            right: "-0.4rem",
            ...handleStyles.output
          }}
        />
      ))}
    </div>
  );
};
