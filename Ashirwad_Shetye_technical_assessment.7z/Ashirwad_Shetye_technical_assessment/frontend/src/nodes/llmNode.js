import React, { useState, useRef, useEffect } from 'react';
import { BaseNode } from './baseNode';
import {Icons} from '../components/ui/icon'

export const LLMNode = ({ id, data }) => {

  const [currText, setCurrText] = useState(data?.text);
  const textareaRef = useRef(null);

  const handleTextChange = (e) => {
    setCurrText(e.target.value);
  };

  useEffect(() => {
    const textarea = textareaRef.current;
    textarea.style.height = 'auto'; // Reset the height
    textarea.style.height = `${Math.min(textarea.scrollHeight, 320)}px`;
  }, [currText]);

  return (
    <BaseNode id={id} inputs={['system', 'prompt']} outputs={['response']}>
      <div className='flex items-center font-semibold gap-1 text-[#6563e4]'>
        <Icons.LLMIcon/>
        <h1 className=''>LLM</h1>
      </div>
      <div className='w-full flex flex-col mt-3'>
        <label className='text-xs gap-1 text-gray-600 flex flex-col'>
          <h3 className=''>Prompt:</h3>
          <textarea
            ref={textareaRef}
            type="text"
            value={currText}
            onChange={handleTextChange}
            placeholder='Enter LLM prompt...'
            className='p-2 text-wrap rounded resize-none border-2'
            style={{ maxHeight: '20rem', overflowY: 'auto' }}
          />
        </label>
      </div>
    </BaseNode>
  );
};