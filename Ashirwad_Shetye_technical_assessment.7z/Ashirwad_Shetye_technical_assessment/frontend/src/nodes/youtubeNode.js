import React, { useState } from 'react';
import { BaseNode } from './baseNode';
import {Icons} from '../components/ui/icon'

export const YoutubeNode = ({ id, data }) => {
  const [currUrl, setCurrUrl] = useState(data?.inputName);

  return (
    <BaseNode id={id} outputs={['value']} inputs={['value']}>
      <div className='flex items-center font-semibold gap-1 text-[#6563e4]'>
        <Icons.YoutubeIcon/>
        <h1 className=''>Youtube</h1>
      </div>
      <div className='mt-3 flex flex-col gap-2'>
        <label className='text-xs gap-1 text-gray-600 flex flex-col'>
          URL:
          <input
            type="text"
            value={currUrl}
            placeholder='www.youtube.com/params...'
            onChange={(e) => setCurrUrl(e.target.value)}
            className='text-sm focus:outline-none focus:text-black text-gray-500'
          />
        </label>
        <h3 className='text-gray-600 text-xs'>Read transcript from a YouTube video</h3>
      </div>
    </BaseNode>
  );
};