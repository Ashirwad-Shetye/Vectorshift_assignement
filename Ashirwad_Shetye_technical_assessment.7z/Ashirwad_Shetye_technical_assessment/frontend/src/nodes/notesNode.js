import React, { useState, useRef, useEffect } from 'react';
import { BaseNode } from './baseNode';
import { Icons } from '../components/ui/icon';

export const NotesNode = ({ id, data }) => {
  const [currText, setCurrText] = useState(data?.text || 'Notes');
  const textareaRef = useRef(null);

  const handleTextChange = (e) => {
    setCurrText(e.target.value);
  };

  useEffect(() => {
    const textarea = textareaRef.current;
    textarea.style.height = 'auto';
    textarea.style.height = `${Math.min(textarea.scrollHeight, 320)}px`;
  }, [currText]);

  return (
    <BaseNode id={id} data={data} outputs={['output']}>
      <div className='flex items-center font-semibold gap-1 text-[#6563e4]'>
        <Icons.NoteIcon />
        <h1 className=''>Notes</h1>
      </div>
      <div className='w-full flex flex-col mt-3'>
        <label className='text-xs gap-1 text-gray-600 flex flex-col'>
          <h3 className=''>Text:</h3>
          <textarea
            ref={textareaRef}
            type="text"
            value={currText}
            onChange={handleTextChange}
            className='p-2 text-wrap rounded resize-none border-2'
            style={{ maxHeight: '20rem', overflowY: 'auto' }}
          />
        </label>
      </div>
    </BaseNode>
  );
};
