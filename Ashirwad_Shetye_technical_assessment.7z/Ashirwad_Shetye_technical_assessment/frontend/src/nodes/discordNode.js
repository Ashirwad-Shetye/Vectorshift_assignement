import React, { useState } from 'react';
import { BaseNode } from './baseNode';
import {Icons} from '../components/ui/icon'

export const DiscordNode = ({ id, data }) => {
  const [inputType, setInputType] = useState(data.inputType || 'Send Message');

  const optionValues = ["Send Message", "Search Message", "Broadcast Message"]

  return (
    <BaseNode id={id} outputs={['value']} inputs={['value']}>
      <div className='flex items-center font-semibold gap-1 text-[#6563e4]'>
        <Icons.DiscordIcon/>
        <h1 className=''>Discord</h1>
      </div>
      <div className='mt-3 flex flex-col gap-5'>
        <label className='text-xs gap-1 text-gray-600 flex flex-col'>
          Action:
          <select
            value={inputType}
            onChange={(e) => setInputType(e.target.value)}
            className='text-sm focus:outline-none focus:text-black text-gray-500'
          >
            {optionValues.map((val, idx) => {
              return (
                <option
                  key={idx}
                  value={val}
                >
                  {val}
                </option>
              )
            })}
          </select>
        </label>
        <div className='w-full flex flex-col justify-center'>
            <button className='bg-[#6563e4] shrink-0 text-white flex items-center justify-center gap-1.5 rounded-full px-2.5 py-1.5 text-lg active:scale-95'>
                <Icons.AddIcon/>
                <h1>Connect Account</h1>
            </button>
            <p className='text-xs text-red-500 mx-auto'>Account connection missing!</p>
        </div>
      </div>
    </BaseNode>
  );
};