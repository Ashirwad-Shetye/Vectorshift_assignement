import { IoDocumentTextOutline as TextIcon, IoPlayCircleOutline as PipelineIcon, IoCloseCircleOutline as CloseIcon } from "react-icons/io5";
import { MdInput as InputIcon, MdOutlineOutput as OutputIcon } from "react-icons/md";
import { FaGithub as GitIcon, FaDiscord as DiscordIcon} from "react-icons/fa6";
import { IoIosSwap as IntegrationIcon, IoIosInformationCircleOutline as InfoIcon, IoMdAdd as AddIcon } from "react-icons/io";
import { BsChatRightText as NoteIcon } from "react-icons/bs";
import { GrStorage as DatabaseIcon } from "react-icons/gr";
import { BiNetworkChart as LLMIcon } from "react-icons/bi";
import { HiOutlineRocketLaunch as SubmitIcon } from "react-icons/hi2";
import { AiOutlineYoutube as YoutubeIcon } from "react-icons/ai";

export const Icons = {
    TextIcon,
    InputIcon,
    OutputIcon,
    PipelineIcon,
    IntegrationIcon,
    InfoIcon,
    CloseIcon,
    NoteIcon,
    DatabaseIcon,
    LLMIcon,
    SubmitIcon,
    YoutubeIcon,
    GitIcon,
    DiscordIcon,
    AddIcon
};