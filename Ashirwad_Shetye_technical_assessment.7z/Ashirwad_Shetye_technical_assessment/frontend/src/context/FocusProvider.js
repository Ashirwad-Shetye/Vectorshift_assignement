import React, { createContext, useContext, useState } from 'react';

const FocusContext = createContext();

export const FocusProvider = ({ children }) => {
  const [focusedNodeId, setFocusedNodeId] = useState(null);

  return (
    <FocusContext.Provider value={{ focusedNodeId, setFocusedNodeId }}>
      {children}
    </FocusContext.Provider>
  );
};

export const useFocus = () => useContext(FocusContext);