

const BASE_API_URL = "http://127.0.0.1:8000";

export const submitData = async (nodes, edges) => {

    try {
        const response = await fetch(`${BASE_API_URL}/pipelines/parse`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ nodes, edges }),
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        return await response.json();
    } catch (error) {
        throw new Error(error.message);
    }
};
