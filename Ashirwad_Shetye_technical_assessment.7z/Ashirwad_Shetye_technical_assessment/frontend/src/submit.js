import { Icons } from "./components/ui/icon";
import { useStore } from './store';
import { useState } from 'react';
import { submitData } from './api/submit_data';
import { toast } from 'sonner'

export const SubmitButton = () => {
    const [isLoading, setIsLoading] = useState(false);
    const { nodes, edges } = useStore((state) => ({
        nodes: state.nodes,
        edges: state.edges,
    }));

    const handleSubmit = async () => {
        setIsLoading(true);
        
        try {
            const result = await submitData(nodes, edges);
            toast.success(`Number of Nodes: ${result.num_nodes}\nNumber of Edges: ${result.num_edges}\nIs DAG: ${result.is_dag}`)
        } catch (error) {
            toast.error(`Error: ${error.message}`)
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div>
            <button
                type="button"
                onClick={handleSubmit}
                className="flex gap-1 items-center justify-center text-white rounded-full w-fit mx-auto px-3 py-1 bg-[#6563e4] active:scale-95 duration-100"
                disabled={isLoading}
            >
                <Icons.SubmitIcon/>
                <p>{isLoading ? 'Submitting...' : 'Submit'}</p>
            </button>
        </div>
    );
}
