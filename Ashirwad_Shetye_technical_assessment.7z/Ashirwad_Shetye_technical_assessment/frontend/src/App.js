import { PipelineToolbar } from './toolbar';
import { PipelineUI } from './ui';
import { SubmitButton } from './submit';
import { Toaster } from 'sonner';

function App() {
  return (
    <div className='h-screen w-screen flex flex-col relative p-2'>
      <div className='flex-1 border-2 border-gray-300 rounded-lg shadow'>
        <Toaster richColors closeButton position="top-right" />
        <PipelineToolbar />
        <PipelineUI />
        <SubmitButton />
      </div>
    </div>
  );
}

export default App;
