/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  ttheme: {
    extend: {
      boxShadow: {
        'custom_purple': '0px 0px 20px 0px rgba(79,70,229,1);',
      },
    },
  },
  plugins: [],
}